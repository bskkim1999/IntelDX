#!/bin/bash    
# state.bash 
echo -n 현재 시간: 
date 
echo 현재 사용자: 
who
echo 시스템 현재 상황: 
uptime

