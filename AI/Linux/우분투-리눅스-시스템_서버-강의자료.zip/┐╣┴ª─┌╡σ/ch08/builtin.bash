#!/bin/bash 
# builtin.bash
echo 이 스크립트 이름: $0
echo 첫 번째 명령줄 인수: $1
echo 모든 명령줄 인수: $*
echo 이 스크립트를 실행하는 프로세스 번호: $$
