#!/bin/bash
# for.bash
for x in $*
do 
    echo $x
done
