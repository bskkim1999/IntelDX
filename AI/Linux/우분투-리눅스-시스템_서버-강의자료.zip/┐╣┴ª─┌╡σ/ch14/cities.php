<?php
$cities = array("서울", "대전", "부산");
foreach ($cities as $city) {
    echo $city . "<br>";
}
?>
