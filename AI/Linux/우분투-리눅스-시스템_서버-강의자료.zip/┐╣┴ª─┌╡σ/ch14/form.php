<!DOCTYPE html>
<html>
<body>
<form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
  이름: <input type="text" name="name">
  <input type="submit" value="제출">
</form>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    echo $name . " 님, " . "반갑습니다";
}
?>
</body>
</html>
