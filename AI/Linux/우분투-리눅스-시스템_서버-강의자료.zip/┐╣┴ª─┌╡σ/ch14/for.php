<?php
for ($i = 1; $i <= 5; $i++) {
    echo $i . "<br>";
}
?>
