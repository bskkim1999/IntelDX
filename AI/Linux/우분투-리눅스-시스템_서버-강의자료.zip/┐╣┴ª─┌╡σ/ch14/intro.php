<?php
    $name = "홍길동";
    $age = 23;
    echo "안녕하세요, 저는 " . $name . "이고, " . $age . "살입니다.";
?>
