<!DOCTYPE html>
<html>
<body>
<h1>오늘의 날짜와 현재 시간은 
<?php
    echo date("Y-m-d H-m-s");
?>
입니다.
</h1>
</body>
</html>
