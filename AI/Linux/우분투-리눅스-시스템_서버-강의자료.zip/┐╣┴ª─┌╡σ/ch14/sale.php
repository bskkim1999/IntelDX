<?php
function saleprice($price, $sale) {
    return $price * (1 - $sale / 100);  
}
echo saleprice(500, 20);
?>
