<?php
$grade = 85;
if ($grade >= 90) {
    echo "A 학점";
} elseif ($grade >= 80) {
    echo "B 학점";
} else {
    echo "C 학점";
}
?>
